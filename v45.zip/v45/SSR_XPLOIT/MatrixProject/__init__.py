from email.policy import default


default_app_config = 'matrixapp.apps.MatrixappConfig'