from django.apps import AppConfig


class MatrixappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'matrixapp'

    def ready(self):
            import matrixapp.signals